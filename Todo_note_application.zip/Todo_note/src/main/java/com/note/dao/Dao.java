package com.note.dao;

public class Dao {

}
